Bootstrap not yet built. Run the bootstrap CI workflow.
